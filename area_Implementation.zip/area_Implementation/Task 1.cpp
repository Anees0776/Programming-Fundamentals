#include<iostream>
using namespace std;
#include"myShape.h"

int main()
{
	Circle c(2);
	Rectangle r(5,4);
	cout <<"Area of Circle: " << c.area() << endl;
	cout << "Area of Rectangle: " << r.area() << endl;



	system("pause");
	return 0;
}