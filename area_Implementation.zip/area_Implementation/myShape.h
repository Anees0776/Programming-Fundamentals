#include"Shape.h"
class Circle: public Shape
{
private:
	float radius;
public:
	Circle(float r)
	{
		radius = r;
	}
	float area()
	{
		return (3.14 * radius * radius);
	}
};

class Rectangle : public Shape
{
private:
	float length;
	float width;
public:
	Rectangle(float l, float w)
	{
		length = l;
		width = w;
	}
	float area()
	{
		return (length * width);
	}
};

