class Shape
{
public:
	virtual float area() = 0;

};