#include<iostream>
using namespace std;
#include"myEmployee.h"

int main()
{
	FullTime f(50000);
	PartTime p(4,1000);

	f.calculateSalary();
	cout << "Part Time Salary: " << p.calculateSalary() << endl;


	system("pause");
	return 0;
}