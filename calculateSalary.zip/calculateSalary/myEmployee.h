#include"Employee.h"

class FullTime :public Employee
{
private:
	int salary;
public:
	FullTime(int s)
	{
		salary = s;
	}

	int calculateSalary()
	{
		cout<<"Salary of Full Time Employee: " << salary << endl;
		return salary;
	}

};

class PartTime : public Employee
{
private:
	int hours;
	int price;
public:
	PartTime(int h, int p)
	{
		hours = h;
		price = p;
	}

	int calculateSalary()
	{
		return hours * price;
	}

};