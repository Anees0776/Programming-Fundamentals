class Employee
{
public:
	virtual int calculateSalary() = 0;



};